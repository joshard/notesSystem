!(function (e, n) {
  "object" == typeof exports && "object" == typeof module
    ? (module.exports = n(require("moment"), require("fullcalendar")))
    : "function" == typeof define && define.amd
    ? define(["moment", "fullcalendar"], n)
    : "object" == typeof exports
    ? n(require("moment"), require("fullcalendar"))
    : n(e.moment, e.FullCalendar);
})("undefined" != typeof self ? self : this, function (e, n) {
  return (function (e) {
    function n(t) {
      if (a[t]) return a[t].exports;
      var r = (a[t] = { i: t, l: !1, exports: {} });
      return e[t].call(r.exports, r, r.exports, n), (r.l = !0), r.exports;
    }
    var a = {};
    return (
      (n.m = e),
      (n.c = a),
      (n.d = function (e, a, t) {
        n.o(e, a) ||
          Object.defineProperty(e, a, {
            configurable: !1,
            enumerable: !0,
            get: t,
          });
      }),
      (n.n = function (e) {
        var a =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return n.d(a, "a", a), a;
      }),
      (n.o = function (e, n) {
        return Object.prototype.hasOwnProperty.call(e, n);
      }),
      (n.p = ""),
      n((n.s = 65))
    );
  })({
    0: function (n, a) {
      n.exports = e;
    },
    1: function (e, a) {
      e.exports = n;
    },
    65: function (e, n, a) {
      Object.defineProperty(n, "__esModule", { value: !0 }), a(66);
      var t = a(1);
      t.datepickerLocale("af", "af", {
        closeText: "Selekteer",
        prevText: "Vorige",
        nextText: "Volgende",
        currentText: "Vandag",
        monthNames: [
          "Januarie",
          "Februarie",
          "Maart",
          "April",
          "Mei",
          "Junie",
          "Julie",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "Desember",
        ],
        monthNamesShort: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Des",
        ],
        dayNames: [
          "Sondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrydag",
          "Saterdag",
        ],
        dayNamesShort: ["Son", "Maa", "Din", "Woe", "Don", "Vry", "Sat"],
        dayNamesMin: ["So", "Ma", "Di", "Wo", "Do", "Vr", "Sa"],
        weekHeader: "Wk",
        dateFormat: "dd/mm/yy",
        firstDay: 1,
        isRTL: !1,
        showMonthAfterYear: !1,
        yearSuffix: "",
      }),
        t.locale("af", {
          buttonText: {
            year: "Jaar",
            month: "Maand",
            week: "Week",
            day: "Dag",
            list: "Agenda",
          },
          allDayHtml: "Heeldag",
          eventLimitText: "Addisionele",
          noEventsMessage: "Daar is geen gebeurtenisse nie",
        });
    },
    66: function (e, n, a) {
      !(function (e, n) {
        n(a(0));
      })(0, function (e) {
        return e.defineLocale("af", {
          months:
            "Januarie_Februarie_Maart_April_Mei_Junie_Julie_Augustus_September_Oktober_November_Desember".split(
              "_"
            ),
          monthsShort: "Jan_Feb_Mrt_Apr_Mei_Jun_Jul_Aug_Sep_Okt_Nov_Des".split(
            "_"
          ),
          weekdays:
            "Sondag_Maandag_Dinsdag_Woensdag_Donderdag_Vrydag_Saterdag".split(
              "_"
            ),
          weekdaysShort: "Son_Maa_Din_Woe_Don_Vry_Sat".split("_"),
          weekdaysMin: "So_Ma_Di_Wo_Do_Vr_Sa".split("_"),
          meridiemParse: /vm|nm/i,
          isPM: function (e) {
            return /^nm$/i.test(e);
          },
          meridiem: function (e, n, a) {
            return e < 12 ? (a ? "vm" : "VM") : a ? "nm" : "NM";
          },
          longDateFormat: {
            LT: "HH:mm",
            LTS: "HH:mm:ss",
            L: "DD/MM/YYYY",
            LL: "D MMMM YYYY",
            LLL: "D MMMM YYYY HH:mm",
            LLLL: "dddd, D MMMM YYYY HH:mm",
          },
          calendar: {
            sameDay: "[Vandag om] LT",
            nextDay: "[Môre om] LT",
            nextWeek: "dddd [om] LT",
            lastDay: "[Gister om] LT",
            lastWeek: "[Laas] dddd [om] LT",
            sameElse: "L",
          },
          relativeTime: {
            future: "oor %s",
            past: "%s gelede",
            s: "'n paar sekondes",
            ss: "%d sekondes",
            m: "'n minuut",
            mm: "%d minute",
            h: "'n uur",
            hh: "%d ure",
            d: "'n dag",
            dd: "%d dae",
            M: "'n maand",
            MM: "%d maande",
            y: "'n jaar",
            yy: "%d jaar",
          },
          dayOfMonthOrdinalParse: /\d{1,2}(ste|de)/,
          ordinal: function (e) {
            return e + (1 === e || 8 === e || e >= 20 ? "ste" : "de");
          },
          week: { dow: 1, doy: 4 },
        });
      });
    },
  });
});
