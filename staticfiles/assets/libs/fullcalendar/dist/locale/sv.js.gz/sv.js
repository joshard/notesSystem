!(function (e, r) {
  "object" == typeof exports && "object" == typeof module
    ? (module.exports = r(require("moment"), require("fullcalendar")))
    : "function" == typeof define && define.amd
    ? define(["moment", "fullcalendar"], r)
    : "object" == typeof exports
    ? r(require("moment"), require("fullcalendar"))
    : r(e.moment, e.FullCalendar);
})("undefined" != typeof self ? self : this, function (e, r) {
  return (function (e) {
    function r(n) {
      if (t[n]) return t[n].exports;
      var a = (t[n] = { i: n, l: !1, exports: {} });
      return e[n].call(a.exports, a, a.exports, r), (a.l = !0), a.exports;
    }
    var t = {};
    return (
      (r.m = e),
      (r.c = t),
      (r.d = function (e, t, n) {
        r.o(e, t) ||
          Object.defineProperty(e, t, {
            configurable: !1,
            enumerable: !0,
            get: n,
          });
      }),
      (r.n = function (e) {
        var t =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return r.d(t, "a", t), t;
      }),
      (r.o = function (e, r) {
        return Object.prototype.hasOwnProperty.call(e, r);
      }),
      (r.p = ""),
      r((r.s = 193))
    );
  })({
    0: function (r, t) {
      r.exports = e;
    },
    1: function (e, t) {
      e.exports = r;
    },
    193: function (e, r, t) {
      Object.defineProperty(r, "__esModule", { value: !0 }), t(194);
      var n = t(1);
      n.datepickerLocale("sv", "sv", {
        closeText: "Stäng",
        prevText: "&#xAB;Förra",
        nextText: "Nästa&#xBB;",
        currentText: "Idag",
        monthNames: [
          "Januari",
          "Februari",
          "Mars",
          "April",
          "Maj",
          "Juni",
          "Juli",
          "Augusti",
          "September",
          "Oktober",
          "November",
          "December",
        ],
        monthNamesShort: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "Maj",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        dayNamesShort: ["Sön", "Mån", "Tis", "Ons", "Tor", "Fre", "Lör"],
        dayNames: [
          "Söndag",
          "Måndag",
          "Tisdag",
          "Onsdag",
          "Torsdag",
          "Fredag",
          "Lördag",
        ],
        dayNamesMin: ["Sö", "Må", "Ti", "On", "To", "Fr", "Lö"],
        weekHeader: "v. ",
        dateFormat: "yy-mm-dd",
        firstDay: 1,
        isRTL: !1,
        showMonthAfterYear: !1,
        yearSuffix: "",
      }),
        n.locale("sv", {
          buttonText: {
            month: "Månad",
            week: "Vecka",
            day: "Dag",
            list: "Program",
          },
          allDayText: "Heldag",
          eventLimitText: "till",
          noEventsMessage: "Inga händelser att visa",
        });
    },
    194: function (e, r, t) {
      !(function (e, r) {
        r(t(0));
      })(0, function (e) {
        return e.defineLocale("sv", {
          months:
            "januari_februari_mars_april_maj_juni_juli_augusti_september_oktober_november_december".split(
              "_"
            ),
          monthsShort: "jan_feb_mar_apr_maj_jun_jul_aug_sep_okt_nov_dec".split(
            "_"
          ),
          weekdays: "söndag_måndag_tisdag_onsdag_torsdag_fredag_lördag".split(
            "_"
          ),
          weekdaysShort: "sön_mån_tis_ons_tor_fre_lör".split("_"),
          weekdaysMin: "sö_må_ti_on_to_fr_lö".split("_"),
          longDateFormat: {
            LT: "HH:mm",
            LTS: "HH:mm:ss",
            L: "YYYY-MM-DD",
            LL: "D MMMM YYYY",
            LLL: "D MMMM YYYY [kl.] HH:mm",
            LLLL: "dddd D MMMM YYYY [kl.] HH:mm",
            lll: "D MMM YYYY HH:mm",
            llll: "ddd D MMM YYYY HH:mm",
          },
          calendar: {
            sameDay: "[Idag] LT",
            nextDay: "[Imorgon] LT",
            lastDay: "[Igår] LT",
            nextWeek: "[På] dddd LT",
            lastWeek: "[I] dddd[s] LT",
            sameElse: "L",
          },
          relativeTime: {
            future: "om %s",
            past: "för %s sedan",
            s: "några sekunder",
            ss: "%d sekunder",
            m: "en minut",
            mm: "%d minuter",
            h: "en timme",
            hh: "%d timmar",
            d: "en dag",
            dd: "%d dagar",
            M: "en månad",
            MM: "%d månader",
            y: "ett år",
            yy: "%d år",
          },
          dayOfMonthOrdinalParse: /\d{1,2}(e|a)/,
          ordinal: function (e) {
            var r = e % 10;
            return (
              e +
              (1 == ~~((e % 100) / 10)
                ? "e"
                : 1 === r
                ? "a"
                : 2 === r
                ? "a"
                : "e")
            );
          },
          week: { dow: 1, doy: 4 },
        });
      });
    },
  });
});
